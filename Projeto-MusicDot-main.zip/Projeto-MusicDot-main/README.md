# Project-MusicDot
Desafio para consolidar conhecimentos e técnicas

# Projeto front-end da Caelum
https://www.caelum.com.br/apostila-html-css-javascript/01EX-arquivos-iniciais

# Layout proposto no desafio
![image](https://github.com/rdeconti/Project-MusicDot/blob/main/challenge/MUSICDOTMOCKUP.png)

# Site oficial na rede
https://www.musicdot.com.br/
